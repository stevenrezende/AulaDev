
package model;
    public enum Prova{NP1, NP2, SUB, EXAME}
    

